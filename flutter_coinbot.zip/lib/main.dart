
import 'package:flutter/material.dart';
import 'screens/bot_control_screen.dart';

void main() {
  runApp(MaterialApp(
    home: BotControlScreen(),
    debugShowCheckedModeBanner: false,
  ));
}


import 'package:flutter/material.dart';
import '../services/api_service.dart';

class BotControlScreen extends StatefulWidget {
  @override
  _BotControlScreenState createState() => _BotControlScreenState();
}

class _BotControlScreenState extends State<BotControlScreen> {
  String selectedBot = "trend";
  List<String> logLines = [];
  bool isRunning = false;
  String status = "";

  void startBot() async {
    final response = await ApiService.startBot(selectedBot);
    setState(() {
      status = response;
      isRunning = true;
    });
    fetchLog();
  }

  void stopBot() async {
    final response = await ApiService.stopBot(selectedBot);
    setState(() {
      status = response;
      isRunning = false;
    });
  }

  void fetchLog() async {
    final lines = await ApiService.getLog(selectedBot);
    setState(() {
      logLines = lines;
    });
  }

  @override
  void initState() {
    super.initState();
    fetchLog();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Bot Kontrol")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButton<String>(
              value: selectedBot,
              items: ["trend", "grid", "scalp"].map((e) =>
                  DropdownMenuItem(value: e, child: Text(e.toUpperCase()))
              ).toList(),
              onChanged: (val) {
                setState(() {
                  selectedBot = val!;
                  fetchLog();
                });
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                    onPressed: startBot, child: Text("Başlat")),
                SizedBox(width: 16),
                ElevatedButton(
                    onPressed: stopBot, child: Text("Durdur")),
              ],
            ),
            SizedBox(height: 16),
            Text("Durum: $status"),
            Expanded(
              child: ListView.builder(
                itemCount: logLines.length,
                itemBuilder: (_, i) => Text(logLines[i]),
              ),
            )
          ],
        ),
      ),
    );
  }
}

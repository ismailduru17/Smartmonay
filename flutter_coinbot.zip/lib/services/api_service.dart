
import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  static String baseUrl = "http://YOUR_BACKEND_IP:8000";

  static Future<String> startBot(String type) async {
    final res = await http.post(Uri.parse("\$baseUrl/bot/start?type=\$type"));
    return json.decode(res.body)["status"];
  }

  static Future<String> stopBot(String type) async {
    final res = await http.post(Uri.parse("\$baseUrl/bot/stop?type=\$type"));
    return json.decode(res.body)["status"];
  }

  static Future<List<String>> getLog(String type) async {
    final res = await http.get(Uri.parse("\$baseUrl/bot/log?type=\$type"));
    final data = json.decode(res.body);
    return List<String>.from(data["log"]);
  }
}

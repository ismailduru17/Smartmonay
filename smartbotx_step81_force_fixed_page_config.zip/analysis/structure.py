import pandas as pd

def detect_choc_bos(candles: pd.DataFrame):
    if len(candles) < 100:
        return []

    signals = []
    window = candles[-100:]
    ref_range = candles[-50:]

    highest_high = ref_range['high'].max()
    lowest_low = ref_range['low'].min()

    recent = window.copy().reset_index(drop=True)
    recent['prev_high'] = recent['high'].shift(1)
    recent['prev_low'] = recent['low'].shift(1)

    trend = "none"
    bos_index = None

    for i in range(1, len(recent)):
        row = recent.iloc[i]
        prev = recent.iloc[i - 1]

        if trend in ["none", "up"] and row['low'] < prev['low']:
            signals.append({"index": i, "type": "BOS", "direction": "down"})
            bos_index = i
            trend = "down"
        elif trend in ["none", "down"] and row['high'] > prev['high']:
            signals.append({"index": i, "type": "BOS", "direction": "up"})
            bos_index = i
            trend = "up"

        if bos_index is not None:
            since_bos = recent.iloc[bos_index:i+1]
            if trend == "down" and row['high'] > since_bos['high'].max():
                signals.append({"index": i, "type": "CHoCH", "direction": "up"})
                bos_index = None
            elif trend == "up" and row['low'] < since_bos['low'].min():
                signals.append({"index": i, "type": "CHoCH", "direction": "down"})
                bos_index = None

    return signals

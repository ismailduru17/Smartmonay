import pandas as pd

def detect_fvg(df: pd.DataFrame):
    fvg_zones = []
    for i in range(1, len(df)-1):
        prev = df.iloc[i-1]
        next = df.iloc[i+1]

        # Bullish FVG
        if prev["high"] < next["low"]:
            fvg_zones.append({
                "index": i,
                "type": "bullish",
                "low": prev["high"],
                "high": next["low"]
            })
        # Bearish FVG
        elif prev["low"] > next["high"]:
            fvg_zones.append({
                "index": i,
                "type": "bearish",
                "low": next["high"],
                "high": prev["low"]
            })
    return fvg_zones

def detect_liquidity_sweeps(df):
    """
    Likidite sweep: önceki dip/tepe seviyesinin aşılması ve ardından ters dönüş.
    Mitigation: önceki OB'ye geri dönüş ve ardından yönün devamı.
    """
    sweep_list = []

    for i in range(2, len(df)):
        # Aşağı yönlü likidite sweep (önceki dip altına iğne, ardından dönüş)
        if df['low'].iloc[i] < df['low'].iloc[i-1] < df['low'].iloc[i-2] and df['close'].iloc[i] > df['open'].iloc[i]:
            sweep_list.append({
                "type": "liquidity_sweep_down",
                "time": df["time"].iloc[i],
                "price": df["low"].iloc[i]
            })

        # Yukarı yönlü likidite sweep (önceki tepe üstüne iğne, ardından dönüş)
        if df['high'].iloc[i] > df['high'].iloc[i-1] > df['high'].iloc[i-2] and df['close'].iloc[i] < df['open'].iloc[i]:
            sweep_list.append({
                "type": "liquidity_sweep_up",
                "time": df["time"].iloc[i],
                "price": df["high"].iloc[i]
            })

    return sweep_list

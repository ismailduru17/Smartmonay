import pandas as pd

def detect_trend_direction(df: pd.DataFrame, window: int = 100):
    if len(df) < window:
        return "unknown"

    recent = df[-window:].copy().reset_index(drop=True)
    highs = recent['high']
    lows = recent['low']

    hh = highs.idxmax()
    ll = lows.idxmin()

    if hh > ll:
        return "up"
    elif ll > hh:
        return "down"
    else:
        return "unknown"

def calculate_formation_target(df: pd.DataFrame, signal_type: str, direction: str):
    if len(df) < 100:
        return None

    recent = df[-100:]
    if signal_type == "CHoCH":
        return recent["high"].max() if direction == "up" else recent["low"].min()
    elif signal_type == "BOS":
        return recent["high"].quantile(0.9) if direction == "up" else recent["low"].quantile(0.1)
    elif "OrderBlock" in signal_type:
        return recent["high"].max() if direction == "up" else recent["low"].min()
    elif "FVG" in signal_type:
        return recent["high"].median() if direction == "up" else recent["low"].median()
    elif "Liquidity" in signal_type:
        return recent["high"].mean() if direction == "up" else recent["low"].mean()
    return None

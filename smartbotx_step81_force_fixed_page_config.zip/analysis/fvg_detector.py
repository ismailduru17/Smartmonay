def detect_fvg(df):
    """
    Fair Value Gap (FVG) tespiti:
    - 3 ardışık mum üzerinden çalışır.
    - Önceki mumun high'ı ile bir sonraki mumun low'u arasında boşluk varsa bu bir FVG'dir.
    """
    fvg_list = []

    for i in range(1, len(df)-1):
        high_prev = df['high'].iloc[i - 1]
        low_next = df['low'].iloc[i + 1]
        low_curr = df['low'].iloc[i]
        high_curr = df['high'].iloc[i]

        if high_prev < low_next:
            fvg = {
                "start_time": df['time'].iloc[i],
                "end_time": df['time'].iloc[i+1],
                "top": low_next,
                "bottom": high_prev,
                "direction": "up" if high_curr > high_prev else "down"
            }
            fvg_list.append(fvg)

    return fvg_list

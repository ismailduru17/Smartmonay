def compute_signal_score(source: str, trend: str, tp: float, entry: float):
    score = 50  # başlangıç puanı

    if source.startswith("CHoCH"):
        score += 15
    elif source.startswith("BOS"):
        score += 10
    elif "OrderBlock" in source:
        score += 8
    elif "Liquidity" in source:
        score += 6
    elif "FVG" in source:
        score += 4

    if trend in source.lower():
        score += 10

    rrr = abs(tp - entry) / (entry * 0.01)
    if rrr >= 1.5:
        score += 10
    elif rrr >= 1.0:
        score += 5

    return min(score, 100)

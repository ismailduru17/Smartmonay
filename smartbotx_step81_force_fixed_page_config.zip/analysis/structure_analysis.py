import pandas as pd

def detect_bos_choch(df):
    """
    BOS (Break of Structure) ve CHoCH (Change of Character) tespiti.
    - Yüksekler veya düşüklerin kırılması durumuna göre tespit yapılır.
    """
    bos_levels = []
    choch_levels = []

    prev_high = df["high"].shift(1)
    prev_low = df["low"].shift(1)

    for i in range(2, len(df)):
        if df["high"].iloc[i] > prev_high.iloc[i] and df["low"].iloc[i] > prev_low.iloc[i]:
            bos_levels.append((df["time"].iloc[i], df["high"].iloc[i]))
        elif df["low"].iloc[i] < prev_low.iloc[i] and df["high"].iloc[i] < prev_high.iloc[i]:
            choch_levels.append((df["time"].iloc[i], df["low"].iloc[i]))

    return bos_levels, choch_levels

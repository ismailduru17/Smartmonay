import pandas as pd

def detect_liquidity_sweeps(df: pd.DataFrame, window: int = 100):
    if len(df) < window + 5:
        return []

    recent = df[-(window + 5):].copy().reset_index(drop=True)
    hh = recent["high"][:-5].max()
    ll = recent["low"][:-5].min()

    sweep_signals = []

    for i in range(window, len(recent)):
        row = recent.iloc[i]

        if row["high"] > hh * 1.0005:
            if recent.iloc[i+1]["close"] < row["close"]:
                sweep_signals.append({
                    "index": i,
                    "type": "sweep_high",
                    "price": row["high"]
                })

        elif row["low"] < ll * 0.9995:
            if recent.iloc[i+1]["close"] > row["close"]:
                sweep_signals.append({
                    "index": i,
                    "type": "sweep_low",
                    "price": row["low"]
                })

    return sweep_signals

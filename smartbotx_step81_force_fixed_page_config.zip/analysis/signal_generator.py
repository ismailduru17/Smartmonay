def generate_signals(df):
    """
    Basit bir mantıkla:
    - BOS varsa ve fiyat yukarı yönlüyse: BUY
    - CHoCH varsa ve fiyat aşağı yönlüyse: SELL
    Entry = son kapanış
    SL/TP = ATR benzeri mantıkla % hesaplama
    """
    signals = []
    for i in range(2, len(df)):
        high_prev = df["high"].iloc[i-1]
        low_prev = df["low"].iloc[i-1]
        close = df["close"].iloc[i]

        direction = None
        if df["high"].iloc[i] > high_prev and df["low"].iloc[i] > low_prev:
            direction = "BUY"
        elif df["low"].iloc[i] < low_prev and df["high"].iloc[i] < high_prev:
            direction = "SELL"

        if direction:
            entry = close
            sl = entry * (0.99 if direction == "BUY" else 1.01)
            tp = entry * (1.02 if direction == "BUY" else 0.98)
            signals.append({
                "index": i,
                "direction": direction,
                "entry": round(entry, 4),
                "sl": round(sl, 4),
                "tp": round(tp, 4)
            })

    return signals

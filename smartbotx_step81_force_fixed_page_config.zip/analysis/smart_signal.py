import pandas as pd
from analysis.structure import detect_choc_bos
from analysis.order_block import detect_order_block
from analysis.liquidity import detect_liquidity_sweeps
from analysis.fvg import detect_fvg
from backend.binance_api import get_klines
from analysis.trend import detect_trend_direction, calculate_formation_target
from analysis.quality import compute_signal_score

def analyze_coin(symbol, interval):
    df = get_klines(symbol, interval, limit=150)
    if df is None or len(df) < 100:
        return None

    # CHoCH / BOS
    structure_signals = detect_choc_bos(df)
    if structure_signals:
        latest = structure_signals[-1]
        if latest["type"] in ["BOS", "CHoCH"]:
            entry = df['close'].iloc[-1]
            sl = df['low'].iloc[-10] if latest["direction"] == "up" else df['high'].iloc[-10]
            tp = entry + (entry - sl) * 1.5 if latest["direction"] == "up" else entry - (sl - entry) * 1.5
            trend = detect_trend_direction(df)
        target = calculate_formation_target(df, latest['type'], trend)
        return {
                "symbol": symbol,
                "signal": "BUY" if latest["direction"] == "up" else "SELL",
                "entry": round(entry, 2),
                "sl": round(sl, 2),
                "tp": round(tp, 2),
                "score": compute_signal_score(latest["type"], trend, tp, entry),
            "trend": trend,
            "target": round(target, 2) if target else None,
                "reason": f"{latest['type']} ({latest['direction']})"
            }

    # Order Block
    ob_blocks = detect_order_block(df)
    if ob_blocks:
        last = ob_blocks[-1]
        entry = df["close"].iloc[-1]
        if last["type"] == "bullish" and entry > last["low"] and entry < last["high"]:
            sl = last["low"]
            tp = entry + (entry - sl) * 1.5
            trend = detect_trend_direction(df)
        target = calculate_formation_target(df, latest['type'], trend)
        return {
                "symbol": symbol,
                "signal": "BUY",
                "entry": round(entry, 2),
                "sl": round(sl, 2),
                "tp": round(tp, 2),
                "score": compute_signal_score("OrderBlock", trend, tp, entry),
            "trend": trend,
            "target": round(target, 2) if target else None,
                "reason": "OrderBlock (bullish)"
            }
        elif last["type"] == "bearish" and entry < last["high"] and entry > last["low"]:
            sl = last["high"]
            tp = entry - (sl - entry) * 1.5
            trend = detect_trend_direction(df)
        target = calculate_formation_target(df, latest['type'], trend)
        return {
                "symbol": symbol,
                "signal": "SELL",
                "entry": round(entry, 2),
                "sl": round(sl, 2),
                "tp": round(tp, 2),
                "score": compute_signal_score("OrderBlock", trend, tp, entry),
            "trend": trend,
            "target": round(target, 2) if target else None,
                "reason": "OrderBlock (bearish)"
            }

    # Liquidity Sweep
    sweeps = detect_liquidity_sweeps(df)
    if sweeps:
        last = sweeps[-1]
        entry = df["close"].iloc[-1]
        if last["type"] == "sweep_low":
            sl = last["price"]
            tp = entry + (entry - sl) * 1.5
            trend = detect_trend_direction(df)
        target = calculate_formation_target(df, latest['type'], trend)
        return {
                "symbol": symbol,
                "signal": "BUY",
                "entry": round(entry, 2),
                "sl": round(sl, 2),
                "tp": round(tp, 2),
                "score": compute_signal_score("Liquidity", trend, tp, entry),
            "trend": trend,
            "target": round(target, 2) if target else None,
                "reason": "Liquidity Sweep (low)"
            }
        elif last["type"] == "sweep_high":
            sl = last["price"]
            tp = entry - (sl - entry) * 1.5
            trend = detect_trend_direction(df)
        target = calculate_formation_target(df, latest['type'], trend)
        return {
                "symbol": symbol,
                "signal": "SELL",
                "entry": round(entry, 2),
                "sl": round(sl, 2),
                "tp": round(tp, 2),
                "score": compute_signal_score("Liquidity", trend, tp, entry),
            "trend": trend,
            "target": round(target, 2) if target else None,
                "reason": "Liquidity Sweep (high)"
            }

    # FVG Tespiti
    fvg_zones = detect_fvg(df)
    if fvg_zones:
        last = fvg_zones[-1]
        entry = df["close"].iloc[-1]
        if last["type"] == "bullish" and entry > last["low"] and entry < last["high"]:
            sl = last["low"]
            tp = entry + (entry - sl) * 1.5
            trend = detect_trend_direction(df)
        target = calculate_formation_target(df, latest['type'], trend)
        return {
                "symbol": symbol,
                "signal": "BUY",
                "entry": round(entry, 2),
                "sl": round(sl, 2),
                "tp": round(tp, 2),
                "score": compute_signal_score("FVG", trend, tp, entry),
            "trend": trend,
            "target": round(target, 2) if target else None,
                "reason": "FVG (bullish)"
            }
        elif last["type"] == "bearish" and entry < last["high"] and entry > last["low"]:
            sl = last["high"]
            tp = entry - (sl - entry) * 1.5
            trend = detect_trend_direction(df)
        target = calculate_formation_target(df, latest['type'], trend)
        return {
                "symbol": symbol,
                "signal": "SELL",
                "entry": round(entry, 2),
                "sl": round(sl, 2),
                "tp": round(tp, 2),
                "score": compute_signal_score("FVG", trend, tp, entry),
            "trend": trend,
            "target": round(target, 2) if target else None,
                "reason": "FVG (bearish)"
            }

    return None

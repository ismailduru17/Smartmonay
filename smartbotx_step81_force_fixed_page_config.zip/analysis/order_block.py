import pandas as pd

def detect_order_block(df: pd.DataFrame, window: int = 50):
    df = df.copy().reset_index(drop=True)
    if len(df) < window:
        return []

    df["body"] = df["close"] - df["open"]
    df["trend"] = df["close"].rolling(3).mean().diff()

    bullish_ob = []
    bearish_ob = []

    for i in range(window, len(df)):
        chunk = df[i-window:i]
        trend_dir = chunk["trend"].mean()
        if trend_dir > 0:
            red = chunk[(chunk["body"] < 0)]
            if not red.empty:
                last_red = red.iloc[-1]
                bullish_ob.append({
                    "index": i,
                    "type": "bullish",
                    "low": last_red["low"],
                    "high": last_red["high"]
                })
        elif trend_dir < 0:
            green = chunk[(chunk["body"] > 0)]
            if not green.empty:
                last_green = green.iloc[-1]
                bearish_ob.append({
                    "index": i,
                    "type": "bearish",
                    "low": last_green["low"],
                    "high": last_green["high"]
                })

    return bullish_ob + bearish_ob

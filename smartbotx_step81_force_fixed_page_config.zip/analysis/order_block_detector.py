def detect_order_blocks(df):
    """
    Basit Order Block (OB) tespiti:
    - Düşüş öncesi son yükseliş (bearish OB)
    - Yükseliş öncesi son düşüş (bullish OB)
    """
    ob_list = []

    for i in range(2, len(df)):
        # Bearish OB (Yukarıdan sert düşüş)
        if df['high'].iloc[i-2] < df['high'].iloc[i-1] and df['high'].iloc[i] < df['high'].iloc[i-1]:
            ob_list.append({
                "type": "bearish",
                "time": df["time"].iloc[i-1],
                "open": df["open"].iloc[i-1],
                "close": df["close"].iloc[i-1],
                "low": df["low"].iloc[i-1],
                "high": df["high"].iloc[i-1]
            })
        # Bullish OB (Aşağıdan sert yükseliş)
        if df['low'].iloc[i-2] > df['low'].iloc[i-1] and df['low'].iloc[i] > df['low'].iloc[i-1]:
            ob_list.append({
                "type": "bullish",
                "time": df["time"].iloc[i-1],
                "open": df["open"].iloc[i-1],
                "close": df["close"].iloc[i-1],
                "low": df["low"].iloc[i-1],
                "high": df["high"].iloc[i-1]
            })
    return ob_list

from backend.signal_alertor import alert_signal

# Bu örnek normal sinyal üretiminden sonra çağrılır
# Örnek sinyal:
signal = {
    "symbol": "BTCUSDT",
    "direction": "BUY",
    "sl": 29500,
    "tp": 31000,
    "score": 89.2
}

alert_signal(signal)
print("Sinyal işlendi ve bildirildi.")

from analysis.signal_generator import generate_signals
from backend.binance_api import get_klines
from backend.binance_trade import send_market_order

def run_bot(symbol="BTCUSDT", interval="1m", quantity=0.01):
    klines = get_klines(symbol, interval)
    import pandas as pd
    df = pd.DataFrame(klines)

    signals = generate_signals(df)
    if not signals:
        return "No signals"

    last_signal = signals[-1]
    response = send_market_order(symbol, last_signal["direction"], quantity)
    return response

import requests
import json
import os

CONFIG_FILE = "config.json"

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)

def send_telegram_alert(message: str):
    config = load_config()
    token = config.get("telegram", {}).get("token")
    chat_id = config.get("telegram", {}).get("chat_id")
    if not token or not chat_id:
        return "Telegram yapılandırılmadı"
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = {"chat_id": chat_id, "text": message}
    response = requests.post(url, data=data)
    return response.text

def send_webhook(data: dict):
    config = load_config()
    url = config.get("webhook_url")
    if not url:
        return "Webhook URL tanımsız"
    response = requests.post(url, json=data)
    return response.text

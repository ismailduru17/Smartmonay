import csv
from datetime import datetime

def log_trade(symbol, direction, entry, sl, tp, result, pnl):
    with open("data/trade_logs.csv", mode="a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([
            datetime.utcnow().isoformat(), symbol, direction,
            entry, sl, tp, result, pnl
        ])

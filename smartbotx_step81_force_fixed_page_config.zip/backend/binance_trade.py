import requests
import time

BASE_URL = "https://testnet.binancefuture.com"
API_KEY = "YOUR_TESTNET_API_KEY"
API_SECRET = "YOUR_TESTNET_SECRET_KEY"

def send_market_order(symbol, side, quantity):
    url = BASE_URL + "/fapi/v1/order"
    headers = {
        "X-MBX-APIKEY": API_KEY
    }

    params = {
        "symbol": symbol,
        "side": side.upper(),
        "type": "MARKET",
        "quantity": quantity,
        "timestamp": int(time.time() * 1000)
    }

    from urllib.parse import urlencode
    import hmac, hashlib

    query_string = urlencode(params)
    signature = hmac.new(API_SECRET.encode('utf-8'), query_string.encode('utf-8'), hashlib.sha256).hexdigest()
    params["signature"] = signature

    response = requests.post(url, headers=headers, params=params)
    return response.json()

import json
import os
from backend.signal_alertor import alert_signal
from analysis.smart_signal import analyze_coin
from backend.binance_api import get_symbols

FAV_FILE = "data/user_favorites.json"
INTERVALS = ["1m", "5m", "15m", "1h", "4h", "1d"]

def load_favorites():
    if os.path.exists(FAV_FILE):
        with open(FAV_FILE) as f:
            return json.load(f)
    return {}

def save_favorites(fav):
    with open(FAV_FILE, "w") as f:
        json.dump(fav, f, indent=2)

def add_favorite(user, symbol):
    fav = load_favorites()
    fav.setdefault(user, [])
    if symbol not in fav[user]:
        fav[user].append(symbol)
        save_favorites(fav)

def remove_favorite(user, symbol):
    fav = load_favorites()
    if user in fav and symbol in fav[user]:
        fav[user].remove(symbol)
        save_favorites(fav)

def get_tradingview_url(symbol):
    base = symbol.replace("USDT", "")
    return f"https://www.tradingview.com/symbols/{base}USDT"

def run_favorite_analysis_loop(user="default_user"):
    fav = load_favorites()
    results = []
    symbols = fav.get(user, [])
    for symbol in symbols:
        for interval in INTERVALS:
            result = analyze_coin(symbol, interval)
            if result and result.get("signal") in ["BUY", "SELL"]:
                alert_signal({
                    "symbol": symbol,
                    "direction": result["signal"],
                    "sl": result["sl"],
                    "tp": result["tp"],
                    "score": result["score"],
                    "interval": interval
                })
                results.append({
                    "symbol": symbol,
                    "interval": interval,
                    "signal": result["signal"],
                    "score": result["score"],
                    "tv": get_tradingview_url(symbol)
                })
    return results

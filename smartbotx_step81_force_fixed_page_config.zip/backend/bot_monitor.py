import json
import os
from datetime import datetime

STATUS_FILE = "data/bot_status.json"

def update_bot_status(symbol, interval, status, last_action=""):
    os.makedirs("data", exist_ok=True)
    status_data = load_status()
    key = f"{symbol}_{interval}"
    status_data[key] = {
        "status": status,
        "last_action": last_action,
        "updated": datetime.utcnow().isoformat()
    }
    with open(STATUS_FILE, "w") as f:
        json.dump(status_data, f, indent=2)

def load_status():
    if not os.path.exists(STATUS_FILE):
        return {}
    with open(STATUS_FILE, "r") as f:
        return json.load(f)

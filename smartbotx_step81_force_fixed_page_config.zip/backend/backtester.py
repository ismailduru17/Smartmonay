import pandas as pd
from analysis.signal_generator import generate_signals

def backtest(df, strategy_rules):
    signals = generate_signals(df)
    total = len(signals)
    win = 0
    loss = 0
    pnl_list = []

    for sig in signals:
        if strategy_rules.get("ml_filter") and sig["direction"] == "SELL":
            continue  # örnek: ML filtresi SELL sinyallerini ele
        pnl = sig["tp"] - sig["entry"] if sig["direction"] == "BUY" else sig["entry"] - sig["tp"]
        pnl = round(pnl, 4)
        pnl_list.append(pnl)
        if pnl > 0:
            win += 1
        else:
            loss += 1

    result = {
        "total_signals": total,
        "wins": win,
        "losses": loss,
        "win_rate": round(win / total * 100, 2) if total else 0,
        "avg_pnl": round(sum(pnl_list) / len(pnl_list), 4) if pnl_list else 0,
        "total_pnl": round(sum(pnl_list), 4)
    }
    return result

from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from backend.bot_monitor import update_bot_status, load_status

app = FastAPI()

# CORS izinleri
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Flutter için açıldı
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class BotRequest(BaseModel):
    symbol: str
    interval: str
    action: str  # "start" | "stop"

@app.post("/bot/control")
def control_bot(req: BotRequest):
    status = "RUNNING" if req.action.lower() == "start" else "STOPPED"
    update_bot_status(req.symbol, req.interval, status, f"Flutter'dan {req.action}")
    return {"message": f"{req.symbol}-{req.interval} botu {status} yapıldı."}

@app.get("/bot/status")
def get_status():
    return load_status()

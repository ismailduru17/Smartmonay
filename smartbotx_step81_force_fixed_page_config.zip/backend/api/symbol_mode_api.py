from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
import requests
from backend.config_mode_manager import get_mode, save_mode

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.get("/mobile/symbols")
def get_all_symbols():
    url = "https://api.binance.com/api/v3/exchangeInfo"
    r = requests.get(url)
    data = r.json()
    symbols = [s["symbol"] for s in data["symbols"] if s["symbol"].endswith("USDT")]
    return symbols

@app.get("/mobile/mode")
def get_current_mode():
    return {"mode": get_mode()}

@app.get("/mobile/mode/set")
def set_mode(mode: str = Query("test", enum=["test", "real"])):
    save_mode(mode)
    return {"message": "Mode updated", "mode": mode}

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from backend.favorite_manager import load_favorites, add_favorite, remove_favorite, run_favorite_analysis_loop, get_tradingview_url

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/mobile/favorites")
def get_favorites(user: str = "default_user"):
    fav = load_favorites()
    return fav.get(user, [])

@app.get("/mobile/favorites/add")
def add(symbol: str, user: str = "default_user"):
    add_favorite(user, symbol)
    return {"message": "Favoriye eklendi", "symbol": symbol}

@app.get("/mobile/favorites/remove")
def remove(symbol: str, user: str = "default_user"):
    remove_favorite(user, symbol)
    return {"message": "Favoriden silindi", "symbol": symbol}

@app.get("/mobile/favorites/with_analysis")
def get_analysis(user: str = "default_user"):
    return run_favorite_analysis_loop(user)

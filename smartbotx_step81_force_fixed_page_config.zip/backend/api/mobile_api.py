from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import json
import os
import pandas as pd

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def load_json_file(filepath):
    if os.path.exists(filepath):
        with open(filepath, "r") as f:
            return json.load(f)
    return {}

@app.get("/mobile/bots")
def get_bot_status():
    return load_json_file("data/bot_status.json")

@app.get("/mobile/strategy")
def get_best_strategy():
    return load_json_file("data/best_strategy.json")

@app.get("/mobile/qtable_size")
def get_q_table_state_count():
    q = load_json_file("data/q_table.json")
    return {"state_count": len(q)}

@app.get("/mobile/score")
def get_overall_stats():
    log_path = "data/trade_logs.csv"
    if not os.path.exists(log_path):
        return {"pnl": 0, "trades": 0, "win_rate": 0}
    df = pd.read_csv(log_path)
    total = len(df)
    pnl = df["pnl"].sum() if "pnl" in df.columns else 0
    wins = (df["result"] == "win").sum() if "result" in df.columns else 0
    win_rate = (wins / total) * 100 if total > 0 else 0
    return {"pnl": round(pnl, 2), "trades": total, "win_rate": round(win_rate, 2)}

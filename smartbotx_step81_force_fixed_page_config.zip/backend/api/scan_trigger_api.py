from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.coin_scanner import scan_all_coins

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.get("/scan/trigger")
def trigger_scan():
    try:
        scan_all_coins()
        return "✅ Coin tarama tamamlandı. Sinyaller varsa alarm gönderildi."
    except Exception as e:
        return f"❌ Hata oluştu: {e}"

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os
import json

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/mobile/signals")
def get_recent_signals():
    path = "data/recent_signals.json"
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return {"signals": []}

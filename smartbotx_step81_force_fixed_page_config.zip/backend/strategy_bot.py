from backend.binance_api import get_klines
from analysis.signal_generator import generate_signals
from strategies.strategy_manager import load_strategy
from backend.binance_trade import send_market_order
from backend.logger import log_trade
import pandas as pd

def run_strategy_bot(symbol, interval, strategy_name, quantity=0.01):
    df = pd.DataFrame(get_klines(symbol, interval, limit=100))
    strategy = load_strategy(strategy_name)
    signals = generate_signals(df)
    if not signals:
        return "No signal"
    
    sig = signals[-1]  # Son sinyal
    direction = sig["direction"]

    # Strateji filtresi örneği: sadece BUY uygula
    if strategy.get("ml_filter") and direction == "SELL":
        return "ML filtresiyle SELL reddedildi"

    # Emir gönder
    order = send_market_order(symbol, direction, quantity)

    # Sonucu logla
    log_trade(
        symbol=symbol,
        direction=direction,
        entry=sig["entry"],
        sl=sig["sl"],
        tp=sig["tp"],
        result="pending",
        pnl=0.0
    )

    return order

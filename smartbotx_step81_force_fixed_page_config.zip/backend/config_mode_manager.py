import json
import os

CONFIG_FILE = "config.json"

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return {"mode": "test"}
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)

def save_mode(mode):
    config = load_config()
    config["mode"] = mode
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

def get_mode():
    return load_config().get("mode", "test")

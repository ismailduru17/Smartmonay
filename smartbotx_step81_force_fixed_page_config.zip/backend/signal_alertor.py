import json
import os
from datetime import datetime
from backend.notifier import send_telegram_alert, send_webhook

SIGNAL_LOG = "data/recent_signals.json"

def alert_signal(signal):
    os.makedirs("data", exist_ok=True)
    if not os.path.exists(SIGNAL_LOG):
        with open(SIGNAL_LOG, "w") as f:
            json.dump({"signals": []}, f)

    with open(SIGNAL_LOG, "r") as f:
        data = json.load(f)

    signal["time"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    data["signals"].insert(0, signal)
    data["signals"] = data["signals"][:20]  # son 20 sinyal tutulur

    with open(SIGNAL_LOG, "w") as f:
        json.dump(data, f, indent=2)

    msg = f"📡 Yeni Sinyal: {signal['symbol']} | {signal['direction']}\nSL: {signal['sl']} TP: {signal['tp']}\nSkor: {signal['score']}"
    send_telegram_alert(msg)
    send_webhook(signal)

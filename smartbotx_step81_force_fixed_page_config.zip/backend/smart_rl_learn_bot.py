import pandas as pd
from backend.binance_api import get_klines
from analysis.smart_signal import generate_smart_signals
from backend.binance_trade import send_market_order
from backend.logger import log_trade
from ml.rl_agent import choose_action, update_q
import random

def extract_state(signal):
    trend = signal.get("trend", "flat")
    ml = "ml_yes" if signal.get("ml_predict", "up") == "up" else "ml_no"
    formasyon = "yes" if signal.get("formasyon", False) else "no"
    return f"{trend}_{ml}_formasyon_{formasyon}"

def run_rl_learning_bot(symbol="BTCUSDT", interval="5m", quantity=0.01):
    df = pd.DataFrame(get_klines(symbol, interval, limit=100))
    signals = generate_smart_signals(df)

    if not signals:
        return "No signal"

    signal = signals[-1]
    state = extract_state(signal)
    action = choose_action(state)

    if action == "HOLD":
        return {"decision": "HOLD", "state": state}

    direction = action
    entry = signal["entry"]
    sl = signal["sl"]
    tp = signal["tp"]

    # emir gönder
    order = send_market_order(symbol, direction, quantity)

    # Ödül simülasyonu (gerçek sonuç beklenemezse)
    simulated_pnl = round(random.uniform(-0.5, 1.0), 2)
    reward = 1.0 if simulated_pnl > 0 else (-1.0 if simulated_pnl < 0 else 0.0)

    # Öğrenme
    update_q(state, direction, reward)

    # logla
    log_trade(
        symbol=symbol,
        direction=direction,
        entry=entry,
        sl=sl,
        tp=tp,
        result="win" if reward > 0 else "loss",
        pnl=simulated_pnl
    )

    return {
        "state": state,
        "decision": direction,
        "entry": entry,
        "sl": sl,
        "tp": tp,
        "pnl": simulated_pnl,
        "reward": reward,
        "order": order
    }

import time
from backend.binance_api import get_all_symbols, get_klines
from analysis.smart_signal import analyze_coin
from backend.signal_alertor import alert_signal

INTERVALS = ["15m", "1h"]
SLEEP = 1  # seconds between each coin check

def scan_all_coins():
    print("🚀 Coin tarama başlatıldı...")
    symbols = get_all_symbols()
    for symbol in symbols:
        if not symbol.endswith("USDT") or "DOWN" in symbol or "UP" in symbol:
            continue
        for interval in INTERVALS:
            try:
                result = analyze_coin(symbol, interval)
                if result and result.get("signal") in ["BUY", "SELL"]:
                    alert_signal({
                        "symbol": symbol,
                        "direction": result["signal"],
                        "sl": result["sl"],
                        "tp": result["tp"],
                        "score": result["score"],
                        "interval": interval
                    })
                    print(f"✅ Sinyal bulundu: {symbol} ({interval}) → {result['signal']}")
            except Exception as e:
                print(f"⚠️ Hata: {symbol} {interval} → {e}")
        time.sleep(SLEEP)

if __name__ == "__main__":
    while True:
        scan_all_coins()
        print("⏳ 5dk sonra tekrar taranacak...
")
        time.sleep(300)

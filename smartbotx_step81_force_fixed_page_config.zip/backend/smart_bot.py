from backend.binance_api import get_klines
from analysis.smart_signal import generate_smart_signals
from backend.binance_trade import send_market_order
from backend.logger import log_trade
import pandas as pd

def run_smart_bot(symbol="BTCUSDT", interval="1m", quantity=0.01):
    df = pd.DataFrame(get_klines(symbol, interval, limit=100))
    signals = generate_smart_signals(df)

    if not signals:
        return "No signal"

    signal = signals[-1]
    direction = signal["signal"]
    entry = signal["entry"]
    sl = signal["sl"]
    tp = signal["tp"]

    # Emir gönder
    order = send_market_order(symbol, direction, quantity)

    # Logla
    log_trade(
        symbol=symbol,
        direction=direction,
        entry=entry,
        sl=sl,
        tp=tp,
        result="pending",
        pnl=0.0
    )

    return {
        "order": order,
        "signal": signal
    }

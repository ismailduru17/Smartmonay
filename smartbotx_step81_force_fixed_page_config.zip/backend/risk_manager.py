import pandas as pd

def calculate_atr(data, period=14):
    df = pd.DataFrame(data, columns=["time", "open", "high", "low", "close", "volume"])
    df["H-L"] = df["high"] - df["low"]
    df["H-PC"] = abs(df["high"] - df["close"].shift(1))
    df["L-PC"] = abs(df["low"] - df["close"].shift(1))
    tr = df[["H-L", "H-PC", "L-PC"]].max(axis=1)
    atr = tr.rolling(window=period).mean()
    return atr.iloc[-1]

def calculate_risk(entry, sl, balance=1000.0, risk_percent=1.0):
    risk_amount = balance * (risk_percent / 100)
    stop_loss_distance = abs(entry - sl)
    if stop_loss_distance == 0:
        return 0
    position_size = risk_amount / stop_loss_distance
    return round(position_size, 5)

def generate_sl_tp(entry, atr, direction, sl_factor=1.5, tp_factor=2.0):
    if direction == "BUY":
        sl = entry - (atr * sl_factor)
        tp = entry + (atr * tp_factor)
    else:
        sl = entry + (atr * sl_factor)
        tp = entry - (atr * tp_factor)
    return round(sl, 2), round(tp, 2)

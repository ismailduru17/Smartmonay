import streamlit as st
import os

st.set_page_config(page_title="SmartBotX Web Panel", layout="wide")
st.sidebar.title("🧠 SmartBotX Panel")

PAGES = {
    "📊 RL Q-Table": "frontend_streamlit/rl_qtable_heatmap.py",
    "📊 Sinyal Skorları": "frontend_streamlit/score_dashboard_panel.py",
    "🧠 GPT + RL Strateji Üretici": "frontend_streamlit/gpt_rl_hybrid_panel.py",
    "🎯 Strateji Optimizasyon": "frontend_streamlit/strategy_optimizer_panel.py",
    "📡 Alarm Gönderme": "frontend_streamlit/alarm_panel.py",
    "👤 Kullanıcı Tavsiyesi": "frontend_streamlit/user_advisor_panel.py",
    "🔁 RL Sync": "frontend_streamlit/strategy_to_rl_panel.py",
    "📈 Favori Coin Analiz": "frontend_streamlit/favorite_analysis_panel.py",
    "🔍 Coin Tarama": "frontend_streamlit/coin_scanner_panel.py",
    "⚙️ Ayarlar": "frontend_streamlit/settings_panel.py",
    "🛠️ Admin Panel": "frontend_streamlit/admin_dashboard.py",

    # Ek modüller
    "📦 Smart Bot Panel": "frontend_streamlit/smart_bot_panel.py",
    "📡 Bot Kontrol Panel": "frontend_streamlit/bot_control_panel.py",
    "📊 Bot İzleme Paneli": "frontend_streamlit/bot_monitor_panel.py",
    "📘 Order Block Panel": "frontend_streamlit/order_block_panel.py",
    "💧 Likidite Panel": "frontend_streamlit/liquidity_chat.py",
    "🧠 RL Yeniden Eğit Paneli": "frontend_streamlit/retrain_rl_panel.py",
    "🧪 Smart Liquid Panel": "frontend_streamlit/smart_liquid_panel.py",
    "🛠️ Auto Strategy Panel": "frontend_streamlit/auto_strategy_panel.py",
    "🧱 Strateji Açıklayıcı": "frontend_streamlit/strategy_explainer.py",
    "🧰 Strateji Üretici Builder": "frontend_streamlit/strategy_builder.py",
    "📅 Haftalık Strateji Paneli": "frontend_streamlit/weekly_strategy_panel.py",
    "📈 Haftalık Rapor": "frontend_streamlit/weekly_report.py"
}

page = st.sidebar.selectbox("Sayfa Seç", list(PAGES.keys()))
page_path = PAGES[page]

# Sayfa kodunu çalıştır
with open(page_path) as code_file:
    code = code_file.read()
    exec(code, globals())

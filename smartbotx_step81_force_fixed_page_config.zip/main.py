import os
os.system("streamlit run frontend_streamlit/live_chart.py")

import pandas as pd
from ml.rl_agent import update_q

LOG_FILE = "data/trade_logs.csv"

def extract_state(row):
    # Örnek durum kodu: "trend_up_ml_yes_formasyon_var"
    trend = row.get("trend", "unknown")
    ml = "ml_yes" if row.get("ml_predict", "up") == "up" else "ml_no"
    formasyon = "yes" if row.get("formasyon") else "no"
    return f"{trend}_{ml}_formasyon_{formasyon}"

def reward(row):
    pnl = float(row.get("pnl", 0))
    if pnl > 0:
        return 1.0
    elif pnl < 0:
        return -1.0
    return 0.0

def train_from_logs():
    df = pd.read_csv(LOG_FILE)
    if "direction" not in df.columns or "pnl" not in df.columns:
        return "Eksik veri"
    for _, row in df.iterrows():
        s = extract_state(row)
        a = row["direction"]
        r = reward(row)
        update_q(s, a, r)
    return "Q-table güncellendi."

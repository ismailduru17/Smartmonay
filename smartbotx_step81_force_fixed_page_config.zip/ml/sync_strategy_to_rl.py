import json
from ml.rl_agent import update_q

BEST_STRATEGY_FILE = "data/best_strategy.json"

# Strateji kodunu RL tablosuna dönüştür ve güncelle
def convert_and_sync():
    if not os.path.exists(BEST_STRATEGY_FILE):
        return "En iyi strateji bulunamadı."

    with open(BEST_STRATEGY_FILE, "r") as f:
        data = json.load(f)
        strat = data["strategy"]

    # Kod çözümlemesi: b1-c1-m1-t1-a0 gibi
    strategy_dict = {s[0]: bool(int(s[1])) for s in strat.split("-")}

    # RL durum tanımı
    trend = "up" if strategy_dict.get("t", False) else "flat"
    ml = "ml_yes" if strategy_dict.get("m", False) else "ml_no"
    formasyon = "yes" if strategy_dict.get("c", False) else "no"  # CHoCH = formasyon

    state = f"{trend}_{ml}_formasyon_{formasyon}"

    # BUY ve SELL aksiyonları için pozitif başlangıç ödülü ver
    update_q(state, "BUY", +0.5)
    update_q(state, "SELL", +0.5)

    return f"Strateji {strat} RL modeline işlendi → state: {state}"

if __name__ == "__main__":
    msg = convert_and_sync()
    print(msg)

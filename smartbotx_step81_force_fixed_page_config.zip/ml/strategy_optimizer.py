import optuna
import pandas as pd
from backend.binance_api import get_klines
from backend.backtester import backtest
from strategies.auto_strategy import apply_strategy_rules, generate_strategy_variants

def objective(trial):
    bos = trial.suggest_categorical("bos", [True, False])
    choch = trial.suggest_categorical("choch", [True, False])
    ml_filter = trial.suggest_categorical("ml_filter", [True, False])
    trend_align = trial.suggest_categorical("trend_align", [True, False])
    atr_filter = trial.suggest_categorical("atr_filter", [True, False])

    rules = {
        "bos": bos,
        "choch": choch,
        "ml_filter": ml_filter,
        "trend_align": trend_align,
        "atr_filter": atr_filter
    }

    df = pd.DataFrame(get_klines("BTCUSDT", "5m", 200))
    result = backtest(df, rules)
    return result["total_pnl"]

def run_optimization(n_trials=25):
    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=n_trials)

    best = study.best_trial
    return {
        "params": best.params,
        "value": best.value,
        "trials": len(study.trials)
    }

if __name__ == "__main__":
    res = run_optimization()
    print(res)

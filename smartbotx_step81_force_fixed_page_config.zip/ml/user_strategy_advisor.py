import pandas as pd
import os
import json

LOG_FILE = "data/trade_logs.csv"

def analyze_user_success(user_id="default_user"):
    if not os.path.exists(LOG_FILE):
        return {"error": "Log dosyası bulunamadı"}

    df = pd.read_csv(LOG_FILE)
    if "strategy" not in df.columns or "result" not in df.columns:
        return {"error": "Eksik kolonlar"}

    user_df = df[df["user"] == user_id] if "user" in df.columns else df.copy()

    grouped = user_df.groupby("strategy").agg({
        "pnl": "sum",
        "result": lambda x: (x == "win").sum(),
        "symbol": "count"
    }).rename(columns={"result": "wins", "symbol": "trades"}).reset_index()

    grouped["win_rate"] = grouped["wins"] / grouped["trades"] * 100
    best = grouped.sort_values(by=["pnl", "win_rate"], ascending=False).head(1).to_dict("records")[0]

    return {
        "recommended_strategy": best["strategy"],
        "pnl": best["pnl"],
        "win_rate": best["win_rate"],
        "total_trades": best["trades"]
    }

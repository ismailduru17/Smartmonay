import numpy as np
from sklearn.linear_model import LogisticRegression
import pickle

MODEL_PATH = "ml/model.pkl"

def train_model(X, y):
    model = LogisticRegression()
    model.fit(X, y)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)

def predict_direction(X):
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    return model.predict(X)

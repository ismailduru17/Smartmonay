import numpy as np
from ml.predictor import train_model

# X: [fiyat değişimi, hacim değişimi]
X = np.array([[0.01, 100], [-0.02, 200], [0.03, 150], [-0.01, 120], [0.05, 180]])
y = np.array([1, 0, 1, 0, 1])  # 1: yukarı, 0: aşağı

train_model(X, y)
print("Model eğitildi ve kaydedildi.")

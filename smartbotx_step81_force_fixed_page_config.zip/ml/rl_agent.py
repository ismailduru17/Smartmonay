import os
import json
from collections import defaultdict

Q_FILE = "data/q_table.json"
ACTIONS = ["BUY", "SELL", "HOLD"]

# Q-table yükle/kaydet
def load_q_table():
    if os.path.exists(Q_FILE):
        with open(Q_FILE, "r") as f:
            return json.load(f)
    return {}

def save_q_table(q_table):
    with open(Q_FILE, "w") as f:
        json.dump(q_table, f, indent=2)

# RL ajanı güncelle
def update_q(state: str, action: str, reward: float, alpha=0.1, gamma=0.9):
    q_table = load_q_table()
    q_table.setdefault(state, {a: 0.0 for a in ACTIONS})
    max_future = max(q_table[state].values())
    q_table[state][action] += alpha * (reward + gamma * max_future - q_table[state][action])
    save_q_table(q_table)

# RL ajanı aksiyon seç
def choose_action(state: str, epsilon=0.1):
    from random import random, choice
    q_table = load_q_table()
    q_table.setdefault(state, {a: 0.0 for a in ACTIONS})

    if random() < epsilon:
        return choice(ACTIONS)
    else:
        return max(q_table[state], key=q_table[state].get)

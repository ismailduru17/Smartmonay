import os
import sys
import datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ml.rl_train_from_logs import train_from_logs

def retrain_daily():
    result = train_from_logs()
    log_line = f"[{datetime.datetime.now().isoformat()}] RL Retrain: {result}"
    with open("data/rl_retrain_log.txt", "a") as f:
        f.write(log_line + "\n")
    print(log_line)

if __name__ == "__main__":
    retrain_daily()

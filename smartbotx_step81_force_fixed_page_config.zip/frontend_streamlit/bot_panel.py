import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.auto_trader import run_bot

st.title("🤖 SmartBotX - Otomatik Bot Sistemi")

symbol = st.selectbox("Coin Seçin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])
qty = st.number_input("Miktar (örnek: 0.01)", value=0.01)

if st.button("🟢 Botu Başlat"):
    result = run_bot(symbol, interval, qty)
    st.write("Emir Yanıtı:", result)

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import json
import os
import pandas as pd
import matplotlib.pyplot as plt



st.title("🧠 RL Q-Table Görselleştirme")

q_path = "data/q_table.json"

if not os.path.exists(q_path):
    st.warning("Q-table bulunamadı.")
else:
    with open(q_path, "r") as f:
        q_data = json.load(f)

    all_rows = []
    for state, actions in q_data.items():
        row = {"state": state}
        for action, value in actions.items():
            row[action] = value
        all_rows.append(row)

    df = pd.DataFrame(all_rows).fillna(0.0)
    df.set_index("state", inplace=True)

    st.subheader("🔢 Q-Table Tablosu")
    st.dataframe(df.style.background_gradient(cmap="YlGnBu", axis=1))

    st.subheader("🔥 Heatmap (BUY ve SELL Aksiyonları)")
    fig, ax = plt.subplots(figsize=(10, 6))
    heat_data = df[["BUY", "SELL"]]
    ax.imshow(heat_data.values, cmap="YlOrRd", aspect="auto")
    ax.set_xticks(range(len(heat_data.columns)))
    ax.set_xticklabels(heat_data.columns)
    ax.set_yticks(range(len(heat_data.index)))
    ax.set_yticklabels(heat_data.index, fontsize=7)
    ax.set_title("Q-Table Heatmap (BUY / SELL)")
    plt.colorbar(ax.imshow(heat_data.values, cmap="YlOrRd", aspect="auto"))
    st.pyplot(fig)

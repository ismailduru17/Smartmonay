import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import pandas as pd
import sys
import os
from backend.binance_api import get_klines
from backend.risk_manager import calculate_atr, generate_sl_tp, calculate_risk


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("🛡️ Risk Yönetimi ve Pozisyon Hesaplama")

symbol = st.selectbox("Coin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["5m", "15m", "1h"])
entry_price = st.number_input("Entry Fiyatı", value=30000.0)
direction = st.radio("Yön", ["BUY", "SELL"])
balance = st.number_input("Toplam Bakiye ($)", value=1000.0)
risk_percent = st.slider("Risk Oranı (%)", min_value=0.5, max_value=5.0, step=0.5, value=1.0)

if st.button("Hesapla"):
    df = get_klines(symbol, interval, 100)
    atr = calculate_atr(df)
    sl, tp = generate_sl_tp(entry_price, atr, direction)
    qty = calculate_risk(entry_price, sl, balance, risk_percent)

    st.success("✅ Sonuçlar")
    st.write(f"ATR: {round(atr, 2)}")
    st.write(f"Stop Loss: {sl}")
    st.write(f"Take Profit: {tp}")
    st.write(f"Pozisyon Miktarı: {qty}")

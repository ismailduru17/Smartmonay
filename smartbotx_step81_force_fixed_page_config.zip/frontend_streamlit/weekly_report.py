import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import pandas as pd
import matplotlib.pyplot as plt
import os
from datetime import datetime

st.title("📅 Haftalık Başarı İstatistikleri")

log_path = "data/trade_logs.csv"

if not os.path.exists(log_path):
    st.warning("Henüz işlem logu bulunamadı.")
else:
    df = pd.read_csv(log_path)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["week"] = df["timestamp"].dt.strftime("%Y-%U")

    weekly_stats = df.groupby("week").agg({
        "result": lambda x: (x == "win").sum(),
        "pnl": "sum",
        "symbol": "count"
    }).rename(columns={"result": "wins", "symbol": "total_trades"})

    weekly_stats["win_rate"] = (weekly_stats["wins"] / weekly_stats["total_trades"]) * 100

    st.dataframe(weekly_stats)

    # Grafikler
    fig1, ax1 = plt.subplots()
    ax1.plot(weekly_stats.index, weekly_stats["pnl"], marker='o')
    ax1.set_title("Haftalık Toplam PnL")
    ax1.set_ylabel("PnL")
    st.pyplot(fig1)

    fig2, ax2 = plt.subplots()
    ax2.plot(weekly_stats.index, weekly_stats["win_rate"], marker='o', color='green')
    ax2.set_title("Haftalık Başarı Oranı (%)")
    ax2.set_ylabel("Win Rate")
    st.pyplot(fig2)

    fig3, ax3 = plt.subplots()
    ax3.bar(weekly_stats.index, weekly_stats["total_trades"], color='orange')
    ax3.set_title("Haftalık İşlem Sayısı")
    ax3.set_ylabel("İşlem Sayısı")
    st.pyplot(fig3)

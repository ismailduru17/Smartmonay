import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
from ml.user_strategy_advisor import analyze_user_success


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("👤 Kişisel Strateji Önerici")

user_id = st.text_input("Kullanıcı ID", value="default_user")

if st.button("🔍 Analiz Et ve Öner"):
    result = analyze_user_success(user_id)
    st.success("Önerilen Strateji ve Performans:")
    st.json(result)

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pandas as pd
import plotly.graph_objects as go
from backend.binance_api import get_klines
from analysis.order_block_detector import detect_order_blocks

st.title("🟤 SmartBotX - Order Block (OB) Analizi")

symbol = st.selectbox("Coin Seçin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])

data = get_klines(symbol, interval)
df = pd.DataFrame(data)
df['time'] = pd.to_datetime(df['time'], unit='ms')

# OB analiz
ob_list = detect_order_blocks(df)

# Grafik oluştur
fig = go.Figure(data=[
    go.Candlestick(x=df['time'],
                   open=df['open'],
                   high=df['high'],
                   low=df['low'],
                   close=df['close'])
])

# OB bölgeleri
for ob in ob_list:
    color = "red" if ob["type"] == "bearish" else "green"
    fig.add_shape(type="rect",
                  x0=pd.to_datetime(ob["time"], unit='ms'),
                  x1=pd.to_datetime(ob["time"], unit='ms') + pd.Timedelta(minutes=1),
                  y0=ob["low"],
                  y1=ob["high"],
                  fillcolor=color,
                  opacity=0.3,
                  layer="below",
                  line_width=0)

fig.update_layout(title=f"{symbol} - {interval} Order Block Bölgeleri", xaxis_rangeslider_visible=False)
st.plotly_chart(fig, use_container_width=True)

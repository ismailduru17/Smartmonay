import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from strategies.gpt_strategy_generator import suggest_strategy_by_gpt
from backend.backtester import backtest
from backend.binance_api import get_klines
import pandas as pd

st.title("🤖 GPT Destekli Strateji Önerici")

market = st.selectbox("Piyasa Durumu", ["trending", "sideways", "volatile"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])
symbol = st.selectbox("Coin", ["BTCUSDT", "ETHUSDT"])

if st.button("🎯 Strateji Öner"):
    strat = suggest_strategy_by_gpt(market, interval)
    st.success("Önerilen Strateji:")
    st.json(strat)

    # Backtest sonucu
    df = pd.DataFrame(get_klines(symbol, interval, limit=150))
    result = backtest(df, strat)
    st.subheader("📊 Backtest Sonucu")
    st.write(result)

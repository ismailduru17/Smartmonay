import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pandas as pd
import plotly.graph_objects as go
from backend.binance_api import get_klines
from analysis.signal_generator import generate_signals

st.title("🚦 SmartBotX - Sinyal Üretimi")

symbol = st.selectbox("Coin Seçin", ["BTCUSDT", "ETHUSDT", "XRPUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m", "1h"])

data = get_klines(symbol, interval)
df = pd.DataFrame(data)
df['time'] = pd.to_datetime(df['time'], unit='ms')

# Sinyal üretimi
signals = generate_signals(df)

# Grafik
fig = go.Figure(data=[
    go.Candlestick(x=df['time'],
                   open=df['open'],
                   high=df['high'],
                   low=df['low'],
                   close=df['close'])
])

for sig in signals:
    t = df['time'].iloc[sig["index"]]
    fig.add_trace(go.Scatter(x=[t], y=[sig["entry"]],
                             mode='markers+text',
                             name=sig["direction"],
                             text=[sig["direction"]],
                             marker=dict(color='green' if sig["direction"] == "BUY" else 'red', size=10),
                             textposition='top center'))
    fig.add_trace(go.Scatter(x=[t], y=[sig["sl"]],
                             mode='markers', name='SL',
                             marker=dict(color='blue', symbol='x', size=6)))
    fig.add_trace(go.Scatter(x=[t], y=[sig["tp"]],
                             mode='markers', name='TP',
                             marker=dict(color='orange', symbol='cross', size=6)))

fig.update_layout(title=f"{symbol} - {interval} Sinyaller", xaxis_rangeslider_visible=False)
st.plotly_chart(fig, use_container_width=True)

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')


def explain(strategy_dict):
    labels = {
        "bos": "BOS (Break of Structure)",
        "choch": "CHoCH (Change of Character)",
        "ml_filter": "ML Filter",
        "trend_align": "Trend Uyumu",
        "atr_filter": "ATR Volatilite Filtresi"
    }
    for k, v in strategy_dict.items():
        if k in labels:
            st.markdown(f"**{labels[k]}** → {'✅ Açık' if v else '❌ Kapalı'}")


import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from strategies.auto_strategy import evaluate_strategies

st.title("🧠 SmartBotX - AutoStrategy Üretici ve Kârlılık Testi")

symbol = st.selectbox("Coin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])

if st.button("⚙️ Strateji Varyasyonlarını Test Et"):
    st.info("Backtest işlemi başlatılıyor...")
    results = evaluate_strategies(symbol, interval)
    top_result = results[0]

    st.success("En kârlı strateji önerisi:")
    st.write(f"🏷️ **Ad:** {top_result['name']}")
    st.write(f"✅ Başarı Oranı: {top_result['win_rate']}%")
    st.write(f"💰 Ortalama PnL: {top_result['avg_pnl']} | Toplam PnL: {top_result['total_pnl']}")
    st.json(top_result["rules"])
    explain(top_result['rules'])

    st.subheader("📊 Diğer Varyasyonlar")
    for res in results[1:6]:
        with st.expander(res["name"]):
            st.write(f"✅ Win Rate: {res['win_rate']}% | 💰 Total PnL: {res['total_pnl']}")
            st.json(res["rules"])

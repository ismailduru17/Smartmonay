import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')


st.title("🧠 Strateji Kodu Açıklayıcı")

code = st.text_input("📋 Strateji Kodu Girin (örn: b1-c1-m1-t1-a0)", value="b1-c1-m1-t1-a0")

components = code.split("-")
descriptions = {
    "b": ("BOS (Break of Structure)", "Fiyat yapısının kırılımı varsa işlem yapılır."),
    "c": ("CHoCH (Change of Character)", "Yön değişimi onaylanırsa işlem yapılır."),
    "m": ("ML Filter (Makine Öğrenimi)", "ML tahmini yön ile uyuşuyorsa işlem yapılır."),
    "t": ("Trend Align", "Sinyal mevcut trend ile uyumluysa işlem yapılır."),
    "a": ("ATR Filter (Volatilite)", "Yeterli volatilite varsa işlem yapılır.")
}

st.markdown("---")
for comp in components:
    if len(comp) != 2:
        continue
    key, val = comp[0], comp[1]
    name, detail = descriptions.get(key, ("Bilinmeyen", "Tanımsız kural"))
    status = "✅ Açık" if val == "1" else "❌ Kapalı"
    st.subheader(f"{name} → {status}")
    st.caption(detail)

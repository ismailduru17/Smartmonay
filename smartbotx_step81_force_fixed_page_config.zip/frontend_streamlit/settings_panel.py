import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

from backend.config_mode_manager import get_mode, save_mode

st.title("⚙️ Ayarlar - Mod Seçimi")
mode = get_mode()
st.write(f"🔁 Mevcut Mod: **{mode.upper()}**")

new_mode = st.selectbox("Modu Seç", ["test", "real"])
if st.button("Kaydet"):
    save_mode(new_mode)
    st.success(f"Yeni mod kaydedildi: {new_mode.upper()}")

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

from backend.favorite_manager import run_favorite_analysis_loop



st.title("📈 Favori Coin Analizi ve Sinyal Üretimi")

user = st.text_input("👤 Kullanıcı ID", value="default_user")

if st.button("🚀 Tüm Favori Coinleri Tara"):
    results = run_favorite_analysis_loop(user)
    if results:
        for r in results:
            st.success(f"{r['symbol']} ({r['interval']}) → {r['signal']} | Skor: {r['score']}")
            st.markdown(f"[📉 TradingView Grafiği]({r['tv']})")
    else:
        st.warning("Sinyal oluşan favori coin bulunamadı.")

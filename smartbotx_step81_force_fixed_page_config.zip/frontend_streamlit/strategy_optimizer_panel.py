import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
from ml.strategy_optimizer import run_optimization


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("🎯 Strateji Optimizasyonu (Optuna)")

trials = st.slider("Deneme Sayısı", min_value=10, max_value=100, step=10, value=25)

if st.button("🚀 Optimizasyonu Başlat"):
    result = run_optimization(n_trials=trials)
    st.success("En iyi strateji:")
    st.json(result)

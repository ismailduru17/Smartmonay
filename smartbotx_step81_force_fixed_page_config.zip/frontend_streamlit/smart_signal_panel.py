import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pandas as pd
from backend.binance_api import get_klines
from analysis.smart_signal import generate_smart_signals

st.title("🧠 SmartBotX - Akıllı Sinyal Motoru (OB + FVG + Sweep)")

symbol = st.selectbox("Coin Seçin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])

data = get_klines(symbol, interval)
df = pd.DataFrame(data)
df['time'] = pd.to_datetime(df['time'], unit='ms')

signals = generate_smart_signals(df)

if signals:
    for s in signals:
        st.success(f"{s['signal']} sinyali tespit edildi")
        st.markdown(f"📌 **Entry:** {s['entry']} | 🛑 SL: {s['sl']} | 🎯 TP: {s['tp']}")
        st.info(f"Sebep: {s['reason']}")
else:
    st.warning("Uygun sinyal bulunamadı.")

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from strategies.strategy_manager import save_strategy, load_strategy, list_strategies

st.title("🧰 SmartBotX - Strateji Oluşturucu")

st.subheader("Yeni Strateji Tanımla")

name = st.text_input("Strateji Adı")

bos = st.checkbox("BOS (Break of Structure)")
choch = st.checkbox("CHoCH (Change of Character)")
ml_filter = st.checkbox("ML Tahmini ile filtrele")
trend_align = st.checkbox("Trend yönü ile uyum")
atr_filter = st.checkbox("ATR filtrele (volatilite)")

if st.button("Stratejiyi Kaydet"):
    if name:
        rules = {
            "bos": bos,
            "choch": choch,
            "ml_filter": ml_filter,
            "trend_align": trend_align,
            "atr_filter": atr_filter
        }
        save_strategy(name, rules)
        st.success(f"'{name}' stratejisi kaydedildi.")
    else:
        st.error("Lütfen strateji adını girin.")

st.subheader("📄 Kayıtlı Stratejiler")

strategies = list_strategies()
for s in strategies:
    with st.expander(f"📘 {s}"):
        st.json(load_strategy(s))

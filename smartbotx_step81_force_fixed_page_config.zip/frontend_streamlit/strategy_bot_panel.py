import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.strategy_bot import run_strategy_bot
from strategies.strategy_manager import list_strategies

st.title("🤖 SmartBotX - Strateji Tabanlı Otomatik Bot")

symbol = st.selectbox("Coin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])
strategy = st.selectbox("Strateji Seç", list_strategies())
qty = st.number_input("Miktar (örnek: 0.01)", value=0.01)

if st.button("🟢 Botu Başlat (Stratejili)"):
    result = run_strategy_bot(symbol, interval, strategy, qty)
    st.write("Sonuç:", result)

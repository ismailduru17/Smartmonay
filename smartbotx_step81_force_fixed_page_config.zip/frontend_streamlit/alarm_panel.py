import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
from backend.notifier import send_telegram_alert, send_webhook


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("🔔 Alarm ve Bildirim Gönder")

msg = st.text_area("Mesaj", value="Yeni işlem sinyali: BTCUSDT BUY")
if st.button("Telegram'a Gönder"):
    result = send_telegram_alert(msg)
    st.success(f"Telegram sonucu: {result}")

if st.button("Webhook'a Gönder"):
    result = send_webhook({"alert": msg})
    st.success(f"Webhook sonucu: {result}")

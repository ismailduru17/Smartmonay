import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')


def explain(strategy_dict):
    labels = {
        "bos": "BOS (Break of Structure)",
        "choch": "CHoCH (Change of Character)",
        "ml_filter": "ML Filter",
        "trend_align": "Trend Uyumu",
        "atr_filter": "ATR Volatilite Filtresi"
    }
    for k, v in strategy_dict.items():
        if k in labels:
            st.markdown(f"**{labels[k]}** → {'✅ Açık' if v else '❌ Kapalı'}")


import sys
import os
import pandas as pd
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.binance_api import get_klines
from backend.backtester import backtest
from strategies.auto_strategy import generate_strategy_variants
from backend.strategy_bot import run_strategy_bot

st.title("🚀 AutoStrategy'den Bot'a Entegrasyon")

symbol = st.selectbox("Coin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])
qty = st.number_input("Miktar", value=0.01)

if st.button("🔁 En İyi Stratejiyi Tespit Et ve Kullan"):
    st.info("Varyasyonlar test ediliyor...")
    df = pd.DataFrame(get_klines(symbol, interval, limit=200))
    all_strats = generate_strategy_variants()
    results = []

    for strat in all_strats:
        res = backtest(df, strat)
        res["rules"] = strat
        results.append(res)

    results = sorted(results, key=lambda x: x["total_pnl"], reverse=True)
    best = results[0]

    st.success("🎯 En iyi strateji belirlendi:")
    st.json(best["rules"])
    explain(best['rules'])

    st.write("🧠 Stratejiye göre bot çalıştırılıyor...")
    bot_result = run_strategy_bot(symbol, interval, qty)

    st.success("Bot sonucu:")
    st.json(bot_result)

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from strategies.gpt_api_strategy import generate_strategy
from backend.backtester import backtest
from backend.binance_api import get_klines
import pandas as pd

st.title("🧠 GPT-4 API Destekli Strateji Üretici")

prompt = st.text_area("GPT-4'e Komut Ver", value="trend dostu kısa vadeli strateji üret")
symbol = st.selectbox("Coin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])

if st.button("🚀 GPT ile Strateji Üret"):
    strat = generate_strategy(prompt)
    st.success("✅ GPT-4 tarafından önerilen strateji:")
    st.json(strat)
    st.subheader("📖 Strateji Açıklaması")
    def explain(strategy_dict):
        labels = {
            "bos": "BOS (Break of Structure)",
            "choch": "CHoCH (Change of Character)",
            "ml_filter": "ML Filter",
            "trend_align": "Trend Uyumu",
            "atr_filter": "ATR Volatilite Filtresi"
        }
        for k, v in strategy_dict.items():
            if k in labels:
                st.markdown(f"**{labels[k]}** → {'✅ Açık' if v else '❌ Kapalı'}")

    explain(strat)


    if isinstance(strat, dict) and "error" not in strat:
        df = pd.DataFrame(get_klines(symbol, interval, limit=150))
        result = backtest(df, strat)
        st.subheader("📊 Backtest Sonucu")
        st.write(result)

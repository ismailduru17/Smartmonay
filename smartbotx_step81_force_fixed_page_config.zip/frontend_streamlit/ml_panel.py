import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import numpy as np
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ml.predictor import predict_direction

st.title("🧠 SmartBotX - ML Tahmin Paneli")

st.write("Model basit bir regresyon modeli ile fiyat yönünü tahmin eder (1: YUKARI, 0: AŞAĞI).")

change = st.number_input("Fiyat Değişimi (%)", value=0.01)
volume = st.number_input("Hacim Değişimi", value=100)

if st.button("Tahmin Et"):
    prediction = predict_direction(np.array([[change, volume]]))
    direction = "📈 YUKARI" if prediction[0] == 1 else "📉 AŞAĞI"
    st.success(f"Tahmin: {direction}")

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
import json
from backend.bot_monitor import load_status


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("🛰️ SmartBotX - Canlı Bot İzleme Paneli")

status = load_status()

if not status:
    st.info("Şu anda aktif çalışan bot yok.")
else:
    for bot, info in status.items():
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown(f"**🤖 Bot:** `{bot}`")
        with col2:
            st.markdown(f"🔄 Durum: `{info['status']}`")
        with col3:
            st.markdown(f"🕒 Son Aksiyon: `{info['last_action']}`")
        st.caption(f"Güncelleme Zamanı: {info['updated']}")
        st.markdown("---")

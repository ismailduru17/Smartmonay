import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import os
import sys
import pandas as pd
import json
from datetime import datetime



sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

LOG_FILE = "data/trade_logs.csv"
Q_TABLE_FILE = "data/q_table.json"

st.title("🔐 SmartBotX Admin Girişi")

password = st.text_input("Şifre", type="password")
if password != "admin123":
    st.warning("Erişim reddedildi. Doğru şifreyi giriniz.")
    st.stop()
st.success("✔️ Erişim onaylandı.")
st.title("🛠️ SmartBotX Admin Panel")

# Kullanıcı ve işlem bilgileri
if os.path.exists(LOG_FILE):
    df = pd.read_csv(LOG_FILE)
    total_trades = len(df)
    total_win = (df["result"] == "win").sum() if "result" in df.columns else 0
    total_pnl = df["pnl"].sum() if "pnl" in df.columns else 0
    unique_users = df["user"].nunique() if "user" in df.columns else 1
    top_strategy = df["strategy"].value_counts().idxmax() if "strategy" in df.columns else "N/A"
else:
    df = pd.DataFrame()
    total_trades = total_win = total_pnl = unique_users = 0
    top_strategy = "N/A"

# Q-table istatistiği
if os.path.exists(Q_TABLE_FILE):
    with open(Q_TABLE_FILE, "r") as f:
        qdata = json.load(f)
    state_count = len(qdata)
else:
    state_count = 0

col1, col2, col3 = st.columns(3)
col1.metric("Toplam İşlem", total_trades)
col2.metric("Toplam PnL", f"${total_pnl:.2f}")
col3.metric("Başarı Oranı", f"{(total_win / total_trades * 100) if total_trades > 0 else 0:.2f}%")

col4, col5 = st.columns(2)
col4.metric("Kullanıcı Sayısı", unique_users)
col5.metric("En Çok Kullanılan Strateji", top_strategy)

st.metric("RL State Sayısı", state_count)

st.markdown("---")
if st.button("🧹 Logları Temizle"):
    open(LOG_FILE, "w").write("")
    st.success("Log dosyası temizlendi.")

if st.button("🔁 RL Q-table Resetle"):
    open(Q_TABLE_FILE, "w").write("{}")
    st.warning("Q-table sıfırlandı.")

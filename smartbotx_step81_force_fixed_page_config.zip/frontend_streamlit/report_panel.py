import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import pandas as pd

st.title("📈 SmartBotX - Performans Raporu")

try:
    df = pd.read_csv("data/trade_logs.csv")
    st.dataframe(df)

    if not df.empty:
        total = len(df)
        success = len(df[df["result"] == "win"])
        fail = len(df[df["result"] == "loss"])
        pnl = df["pnl"].sum()

        st.markdown(f"✅ **Toplam İşlem:** {total}")
        st.markdown(f"🟢 **Başarı Oranı:** {round(success / total * 100, 2)}%")
        st.markdown(f"📉 **Zarar Oranı:** {round(fail / total * 100, 2)}%")
        st.markdown(f"💰 **Toplam PnL:** {round(pnl, 2)} USDT")
    else:
        st.info("Henüz işlem yapılmamış.")
except FileNotFoundError:
    st.error("trade_logs.csv bulunamadı.")

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')


def explain(strategy_dict):
    labels = {
        "bos": "BOS (Break of Structure)",
        "choch": "CHoCH (Change of Character)",
        "ml_filter": "ML Filter",
        "trend_align": "Trend Uyumu",
        "atr_filter": "ATR Volatilite Filtresi"
    }
    for k, v in strategy_dict.items():
        if k in labels:
            st.markdown(f"**{labels[k]}** → {'✅ Açık' if v else '❌ Kapalı'}")


import pandas as pd
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.binance_api import get_klines
from backend.backtester import backtest
from strategies.strategy_manager import list_strategies, load_strategy
import matplotlib.pyplot as plt

st.title("📈 SmartBotX - Strateji Karşılaştırma")

symbol = st.selectbox("Coin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m"])
strategies = list_strategies()

results = []

if st.button("📊 Karşılaştırmayı Başlat"):
    klines = get_klines(symbol, interval, limit=200)
    df = pd.DataFrame(klines)

    for s in strategies:
        rules = load_strategy(s)
        res = backtest(df, rules)
        res["name"] = s
        results.append(res)

    if results:
        df_result = pd.DataFrame(results)
        st.dataframe(df_result[["name", "win_rate", "avg_pnl", "total_pnl"]])

        # Grafik 1: Başarı oranı
        fig1, ax1 = plt.subplots()
        ax1.bar(df_result["name"], df_result["win_rate"])
        ax1.set_ylabel("Başarı Oranı (%)")
        ax1.set_title("Strateji Başarı Karşılaştırması")
        st.pyplot(fig1)

        # Grafik 2: Ortalama PnL
        fig2, ax2 = plt.subplots()
        ax2.bar(df_result["name"], df_result["avg_pnl"])
        ax2.set_ylabel("Ortalama PnL")
        ax2.set_title("Strateji Karlılık Karşılaştırması")
        st.pyplot(fig2)

        # Grafik 3: Toplam Kar
        fig3, ax3 = plt.subplots()
        ax3.bar(df_result["name"], df_result["total_pnl"])
        ax3.set_ylabel("Toplam PnL")
        ax3.set_title("Strateji Toplam Getiri")
        st.pyplot(fig3)

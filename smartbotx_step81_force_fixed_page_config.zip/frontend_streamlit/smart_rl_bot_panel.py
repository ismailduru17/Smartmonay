import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
from backend.smart_rl_bot import run_rl_smart_bot


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("🤖 RL Destekli SmartBotX")

symbol = st.selectbox("Coin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])
qty = st.number_input("Miktar", value=0.01)

if st.button("🚀 RL Smart Botu Çalıştır"):
    result = run_rl_smart_bot(symbol, interval, qty)
    st.json(result)

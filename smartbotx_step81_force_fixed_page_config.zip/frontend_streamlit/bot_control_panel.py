import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import os
import sys
import json
from datetime import datetime
from backend.bot_monitor import load_status, update_bot_status


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("🎛️ SmartBotX - Bot Kontrol Paneli")

# Bot tanımı (örnek botlar sabit tanımlanır)
bot_list = [
    {"symbol": "BTCUSDT", "interval": "5m"},
    {"symbol": "ETHUSDT", "interval": "1m"},
    {"symbol": "XRPUSDT", "interval": "15m"}
]

for bot in bot_list:
    key = f"{bot['symbol']}_{bot['interval']}"
    col1, col2, col3 = st.columns([3, 2, 2])
    with col1:
        st.markdown(f"**🤖 {bot['symbol']} @ {bot['interval']}**")
    with col2:
        if st.button(f"▶️ Başlat", key=f"start_{key}"):
            update_bot_status(bot["symbol"], bot["interval"], "RUNNING", "Elle başlatıldı")
            st.success(f"{key} başlatıldı.")
    with col3:
        if st.button(f"⏹️ Durdur", key=f"stop_{key}"):
            update_bot_status(bot["symbol"], bot["interval"], "STOPPED", "Elle durduruldu")
            st.warning(f"{key} durduruldu.")

st.markdown("---")

# Aktif durumları göster
st.subheader("🔄 Canlı Durumlar")
status = load_status()
if not status:
    st.info("Henüz kayıtlı bot yok.")
else:
    for bot_key, info in status.items():
        st.markdown(f"**{bot_key}** → `{info['status']}` | 🕒 {info['updated']} | ✏️ {info['last_action']}")

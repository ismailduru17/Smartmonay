import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pandas as pd
import plotly.graph_objects as go
from backend.binance_api import get_klines
from analysis.liquidity_detector import detect_liquidity_sweeps

st.title("💧 SmartBotX - Liquidity Sweep & Mitigation Analizi")

symbol = st.selectbox("Coin Seçin", ["BTCUSDT", "ETHUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])

data = get_klines(symbol, interval)
df = pd.DataFrame(data)
df['time'] = pd.to_datetime(df['time'], unit='ms')

# Sweep analiz
sweep_list = detect_liquidity_sweeps(df)

# Grafik
fig = go.Figure(data=[
    go.Candlestick(x=df['time'],
                   open=df['open'],
                   high=df['high'],
                   low=df['low'],
                   close=df['close'])
])

for s in sweep_list:
    color = "blue" if s["type"] == "liquidity_sweep_down" else "orange"
    label = "Liq. Sweep ↓" if s["type"] == "liquidity_sweep_down" else "Liq. Sweep ↑"
    fig.add_trace(go.Scatter(
        x=[pd.to_datetime(s["time"], unit='ms')],
        y=[s["price"]],
        mode='markers+text',
        marker=dict(color=color, size=10),
        text=[label],
        textposition="top center"
    ))

fig.update_layout(title=f"{symbol} - {interval} Likidite Süpürmeleri", xaxis_rangeslider_visible=False)
st.plotly_chart(fig, use_container_width=True)

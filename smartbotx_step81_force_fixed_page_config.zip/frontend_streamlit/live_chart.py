import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import pandas as pd
import plotly.graph_objects as go
from backend.binance_api import get_klines

st.title("📈 SmartBotX - Canlı Grafik")

symbol = st.selectbox("Coin Seçin", ["BTCUSDT", "ETHUSDT", "XRPUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m", "1h"])

data = get_klines(symbol, interval)
df = pd.DataFrame(data)
df['time'] = pd.to_datetime(df['time'], unit='ms')

fig = go.Figure(data=[
    go.Candlestick(x=df['time'],
                   open=df['open'],
                   high=df['high'],
                   low=df['low'],
                   close=df['close'])
])
fig.update_layout(title=f"{symbol} - {interval} Grafik", xaxis_rangeslider_visible=False)
st.plotly_chart(fig, use_container_width=True)

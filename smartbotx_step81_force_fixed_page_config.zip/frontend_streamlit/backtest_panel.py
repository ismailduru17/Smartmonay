import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import pandas as pd
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.binance_api import get_klines
from backend.backtester import backtest
from strategies.strategy_manager import list_strategies, load_strategy

st.title("📊 SmartBotX - Strateji Backtest")

symbol = st.selectbox("Coin", ["BTCUSDT", "ETHUSDT", "XRPUSDT"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])
strategy_name = st.selectbox("Strateji Seç", list_strategies())

if st.button("🔁 Backtest Başlat"):
    st.info("Veri alınıyor ve analiz yapılıyor...")
    klines = get_klines(symbol, interval, limit=200)
    df = pd.DataFrame(klines)
    rules = load_strategy(strategy_name)
    result = backtest(df, rules)

    st.success(f"Strateji: {strategy_name}")
    st.write(result)

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
from ml.sync_strategy_to_rl import convert_and_sync


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("🔁 Seçilen Stratejiyi RL Modeline Aktar")

if st.button("🧠 Stratejiyi RL'ye İşle"):
    msg = convert_and_sync()
    st.success(msg)

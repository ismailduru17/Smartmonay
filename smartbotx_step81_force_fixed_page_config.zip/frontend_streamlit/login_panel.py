import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.auth import authenticate

st.title("🔐 SmartBotX Giriş")

if "login" not in st.session_state:
    st.session_state.login = False
    st.session_state.username = ""
    st.session_state.subscription = ""

if not st.session_state.login:
    username = st.text_input("Kullanıcı Adı")
    password = st.text_input("Şifre", type="password")
    if st.button("Giriş Yap"):
        valid, sub = authenticate(username, password)
        if valid:
            st.success("Giriş başarılı")
            st.session_state.login = True
            st.session_state.username = username
            st.session_state.subscription = sub
            st.experimental_rerun()
        else:
            st.error("Hatalı giriş")
else:
    st.success(f"👋 Hoş geldin {st.session_state.username}")
    st.info(f"🧾 Abonelik türü: {st.session_state.subscription}")
    if st.button("Çıkış Yap"):
        st.session_state.login = False
        st.session_state.username = ""
        st.experimental_rerun()

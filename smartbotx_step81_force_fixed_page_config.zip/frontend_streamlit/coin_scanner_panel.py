import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

from backend.coin_scanner import scan_all_coins



st.title("🔍 Coin Tarama Modülü")

st.markdown("Bu sistem Binance üzerindeki tüm coinleri seçilen zaman dilimlerinde analiz eder.")

if st.button("🚀 Taramayı Başlat"):
    st.info("Taramaya başlandı... Lütfen bekleyin.")
    scan_all_coins()
    st.success("✅ Tarama tamamlandı. Sinyaller varsa alarm gönderildi.")

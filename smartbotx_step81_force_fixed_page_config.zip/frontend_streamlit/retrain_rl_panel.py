import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import os
import sys
from ml.retrain_rl_model import retrain_daily


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("🔁 RL Modelini Güncelle")

if st.button("🧠 RL Modelini Yeniden Eğit"):
    retrain_daily()
    st.success("Q-Table güncellendi.")

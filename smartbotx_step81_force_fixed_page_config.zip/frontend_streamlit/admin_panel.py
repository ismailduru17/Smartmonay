import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import os
import json
from datetime import datetime

st.title("🛠️ SmartBotX - Admin Paneli")

# Yetki kontrol (basit kontrol)
admin_user = "admin"
if st.session_state.get("username") != admin_user:
    st.error("Bu sayfa yalnızca admin kullanıcıya açıktır.")
    st.stop()

# Kullanıcı yönetimi
st.subheader("👥 Kullanıcı Listesi")
try:
    with open("backend/users.json", "r") as f:
        users = json.load(f)

    for user, info in users.items():
        col1, col2, col3 = st.columns([2,2,2])
        with col1:
            st.write(f"👤 **{user}**")
        with col2:
            st.write(f"🔐 Şifre: `{info['password']}`")
        with col3:
            st.write(f"🎫 Abonelik: `{info['subscription']}`")

    if st.checkbox("Yeni Kullanıcı Ekle"):
        new_user = st.text_input("Kullanıcı Adı")
        new_pass = st.text_input("Şifre")
        new_sub = st.selectbox("Abonelik Türü", ["trial", "premium"])
        if st.button("Kaydet"):
            users[new_user] = {
                "password": new_pass,
                "subscription": new_sub
            }
            with open("backend/users.json", "w") as f:
                json.dump(users, f, indent=2)
            st.success(f"{new_user} başarıyla eklendi.")
            st.experimental_rerun()

except FileNotFoundError:
    st.error("users.json bulunamadı")

# Sistem izleme (örnek log gösterimi)
st.subheader("📜 Sistem Logları")
log_path = "data/trade_logs.csv"
if os.path.exists(log_path):
    with open(log_path, "r") as f:
        logs = f.readlines()
        st.code("".join(logs[-10:]), language="text")
else:
    st.info("Henüz işlem logu yok.")

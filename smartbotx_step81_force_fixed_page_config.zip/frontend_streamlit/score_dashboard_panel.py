import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import matplotlib.pyplot as plt



st.title("📊 Sinyal Skoru Dağılımı")

signals = [
    ("CHoCH (up)", 90),
    ("OrderBlock (bullish)", 78),
    ("Liquidity Sweep (low)", 70),
    ("FVG (bullish)", 68),
    ("BOS (down)", 83),
    ("CHoCH (down)", 88),
    ("FVG (bearish)", 65),
    ("OrderBlock (bearish)", 74),
    ("Liquidity Sweep (high)", 72)
]

names = [s[0] for s in signals]
scores = [s[1] for s in signals]

fig, ax = plt.subplots(figsize=(10, 5))
bars = ax.barh(names, scores, color='seagreen')
ax.set_xlabel("Skor")
ax.set_title("Sinyal Türlerine Göre Kalite Skorları")

for bar in bars:
    width = bar.get_width()
    ax.text(width + 1, bar.get_y() + bar.get_height()/2, f'{int(width)}', va='center')

st.pyplot(fig)

import streamlit as st
st.set_page_config(page_title='SmartBotX', layout='wide')

import sys
import os
import json
from strategies.gpt_strategy_generator import suggest_strategy_by_gpt
from strategies.gpt_rl_hybrid_generator import evaluate_with_rl


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

st.title("🧠 GPT + RL Hibrit Strateji Üretici")

market = st.selectbox("Piyasa Durumu", ["trending", "sideways", "volatile"])
interval = st.selectbox("Zaman Dilimi", ["1m", "5m", "15m"])

if st.button("🤖 Strateji Üret ve RL ile Değerlendir"):
    gpt_strategy = suggest_strategy_by_gpt(market, interval)
    st.subheader("GPT Önerisi:")
    st.json(gpt_strategy)

    eval_result = evaluate_with_rl(gpt_strategy)
    st.subheader("🧠 RL Aksiyonu:")
    st.json(eval_result)

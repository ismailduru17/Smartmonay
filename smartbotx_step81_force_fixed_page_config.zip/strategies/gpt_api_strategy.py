import openai
import json

def load_api_key():
    with open("config.json", "r") as f:
        config = json.load(f)
    return config["openai_api_key"]

def generate_strategy(prompt="trend dostu kısa vadeli strateji üret"):
    openai.api_key = load_api_key()

    system_msg = "Sen bir algoritmik strateji danışmanısın. Çıktı sadece JSON formatında olsun. Anahtarlar: bos, choch, ml_filter, trend_align, atr_filter. Her biri true/false olmalı."

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": system_msg},
            {"role": "user", "content": prompt}
        ],
        temperature=0.5
    )

    content = response["choices"][0]["message"]["content"]
    try:
        parsed = json.loads(content)
        return parsed
    except Exception as e:
        return {"error": "JSON parse hatası", "content": content}

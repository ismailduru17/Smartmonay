import json
import os

STRATEGY_FOLDER = "strategies/"

def save_strategy(name, rules):
    os.makedirs(STRATEGY_FOLDER, exist_ok=True)
    with open(os.path.join(STRATEGY_FOLDER, f"{name}.json"), "w") as f:
        json.dump(rules, f, indent=2)

def load_strategy(name):
    with open(os.path.join(STRATEGY_FOLDER, f"{name}.json"), "r") as f:
        return json.load(f)

def list_strategies():
    if not os.path.exists(STRATEGY_FOLDER):
        return []
    return [f[:-5] for f in os.listdir(STRATEGY_FOLDER) if f.endswith(".json")]

import pandas as pd
import json
import os

LOG_FILE = "data/trade_logs.csv"
BEST_STRATEGY_FILE = "data/best_strategy.json"

def compute_weekly_performance():
    if not os.path.exists(LOG_FILE):
        return None

    df = pd.read_csv(LOG_FILE)
    if "timestamp" not in df.columns or "strategy" not in df.columns or "pnl" not in df.columns:
        return None

    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["week"] = df["timestamp"].dt.strftime("%Y-%U")

    grouped = df.groupby(["week", "strategy"]).agg({
        "pnl": "sum",
        "result": lambda x: (x == "win").sum(),
        "symbol": "count"
    }).rename(columns={"result": "wins", "symbol": "trades"}).reset_index()

    grouped["win_rate"] = (grouped["wins"] / grouped["trades"]) * 100

    last_week = grouped["week"].max()
    weekly_df = grouped[grouped["week"] == last_week]

    best = weekly_df.sort_values(by=["pnl", "win_rate"], ascending=False).iloc[0]
    strategy_name = best["strategy"]
    win_rate = best["win_rate"]
    pnl = best["pnl"]

    with open(BEST_STRATEGY_FILE, "w") as f:
        json.dump({
            "strategy": strategy_name,
            "week": last_week,
            "pnl": pnl,
            "win_rate": win_rate
        }, f, indent=2)

    return strategy_name, win_rate, pnl

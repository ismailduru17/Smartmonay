import random

def suggest_strategy_by_gpt(market_condition="sideways", timeframe="5m"):
    """
    GPT destekli strateji önericisi (simülasyon)
    Gerçek GPT entegrasyonu için OpenAI API ile tamamlanabilir
    """
    templates = {
        "trending": [
            {"bos": True, "choch": False, "ml_filter": True, "trend_align": True, "atr_filter": True},
            {"bos": True, "choch": True, "ml_filter": False, "trend_align": True, "atr_filter": False}
        ],
        "sideways": [
            {"bos": False, "choch": True, "ml_filter": True, "trend_align": False, "atr_filter": True},
            {"bos": False, "choch": True, "ml_filter": False, "trend_align": False, "atr_filter": False}
        ],
        "volatile": [
            {"bos": True, "choch": True, "ml_filter": True, "trend_align": False, "atr_filter": True},
            {"bos": True, "choch": False, "ml_filter": True, "trend_align": False, "atr_filter": True}
        ]
    }

    suggestions = templates.get(market_condition.lower(), templates["sideways"])
    selected = random.choice(suggestions)
    selected["source"] = "GPT Strategy Advisor"
    selected["market"] = market_condition
    selected["timeframe"] = timeframe
    return selected

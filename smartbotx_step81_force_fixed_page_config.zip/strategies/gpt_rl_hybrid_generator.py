import json
from ml.rl_agent import choose_action

def gpt_to_state(strategy: dict):
    trend = "up" if strategy.get("trend_align", False) else "flat"
    ml = "ml_yes" if strategy.get("ml_filter", False) else "ml_no"
    formasyon = "yes" if strategy.get("choch", False) else "no"
    return f"{trend}_{ml}_formasyon_{formasyon}"

def evaluate_with_rl(strategy: dict):
    state = gpt_to_state(strategy)
    action = choose_action(state, epsilon=0.0)
    return {"state": state, "rl_action": action}

from itertools import product
from backend.backtester import backtest
import pandas as pd
from backend.binance_api import get_klines

def generate_strategy_variants():
    """
    BOS / CHoCH / ML / Trend / ATR gibi kurallardan tüm varyasyonları üret
    """
    keys = ["bos", "choch", "ml_filter", "trend_align", "atr_filter"]
    values = [[True, False]] * len(keys)
    all_combinations = list(product(*values))

    strategies = []
    for combo in all_combinations:
        strategy = dict(zip(keys, combo))
        strategy["name"] = "-".join([f"{k[0]}{int(v)}" for k, v in strategy.items() if k != "name"])
        strategies.append(strategy)
    return strategies

def evaluate_strategies(symbol="BTCUSDT", interval="5m", limit=200):
    df = pd.DataFrame(get_klines(symbol, interval, limit))
    strategies = generate_strategy_variants()

    results = []
    for strat in strategies:
        res = backtest(df, strat)
        res["name"] = strat["name"]
        res["rules"] = strat
        results.append(res)

    return sorted(results, key=lambda x: x["total_pnl"], reverse=True)
